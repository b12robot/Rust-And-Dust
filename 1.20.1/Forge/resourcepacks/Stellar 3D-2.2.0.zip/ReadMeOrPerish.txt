Hello there future people!
We're guessing you're here for the express reason of finding out what we would like you to do with our pack (if you will oh so courteously obligle).
Or you like our trivia for some reason.

=======================================================================================
=-------------------------------------------------------------------------------------=
=======================================================================================


What you can do with our resource pack:

- You may modify this for personal use, and yes you can privately send your customized version to friends, just no publishing it anywhere and saying you made it.
*If you are using a customized version of the pack in gameplay videos please state it in the video or description!

- You may use this in gameplay videos, why would we make a pack where you can't?

- You may add this resource pack to modpacks, but it must NOT be modified* and credit must be directly given in the description as well as a clear link to the source on Modrinth.
*unless said modifications are directly approved by us

- Of course you can download it, you already did that.

- Yes, you can take inspiration.

- Yes, you can pick through the files to see how we did stuff to learn how to do it yourself! (If you're interested in modeling blocks/items, use Blockbench).
However, joining the Discord (https://discord.gg/hQqx2mqMz8) would probably be a lot more beneficial to you!

- You may NOT smell the textures.

- Just use common sense, this is obviously free for personal use bla bla bla don't republish it bla bla license is all rights reserved bla bla bla.

- If we suddenly die, or dissapear from the internet, and we answer no replies from anyone, ever, for at LEAST 5 whole years, then yes you can freely use this pack for whatever you want,
remixing it, continuing to update it (via forking it), etc. Just at least attempt to contact us on Discord and other platforms first. Also just remember to always credit the original pack somewhere obvious.

- Don't use our branding, it's ours.

- Any changes in future versions of this ReadMe overwrite any changes in previous versions.

- Anything we say preceeds anything in the license (including previous versions), we reserve the right to revoke any priveleges given for any reason. Our word. Our pack. Our say.


=======================================================================================
=-------------------------------------------------------------------------------------=
=======================================================================================


Now have some trivia as a reward for clicking on the readme!

Cool Trivia:

- All the splashes above "As seen on TV!" are our custom splashes, check em out.

- Han shot first

- This was our third attempt at a texture pack that justs tweaks the textures
(the first one was before the major texture change and the second one was the 2nd or 3rd beta textures that got scrapped.)

- Valve can't count past 2 (Dangit give us Portal 3!)

- We are a system, which means there are multiple self aware entities in one head. Otherwise known as plurality!

- Our favorite hobby is war profiteering


Oh also, if you got this anywhere besides Modrinth or PMC, it was illegally stolen.
These are the official links to Modrinth:
https://modrinth.com/resourcepack/stellar-tweaks
https://modrinth.com/resourcepack/stellar-3d